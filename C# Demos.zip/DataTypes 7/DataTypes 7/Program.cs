﻿using System;

namespace DataTypes_7
{
    class StrDemo
    {
        static void Main()
        {
            Console.WriteLine("First line\nSecond line");
            Console.WriteLine("A\tB\tC");
            Console.WriteLine("D\tE\tF");
        }
    }
}
