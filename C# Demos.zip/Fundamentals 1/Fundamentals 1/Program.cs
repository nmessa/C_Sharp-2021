﻿using System;

namespace Fundamentals_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C# gives you programming power."); 
        }
    }
}
