﻿using System;

namespace While_1
{
    class WhileDemo
    {
        static void Main()
        {
            char ch;

            // Print the alphabet using a while loop. 
            ch = 'a';
            while (ch <= 'z')
            {
                Console.Write(ch);
                ch++;
            }
            Console.WriteLine();
        }
    }
}
