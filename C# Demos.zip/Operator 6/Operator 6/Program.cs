﻿using System;

namespace Operator_6
{
    class LtoD
    {
        static void Main()
        {
            long L;
            double D;

            L = 100123285L;
            D = L;

            Console.WriteLine("L and D: " + L + " " + D);
        }
    }

}
